package com.example.Proj;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProjectNsdcApplicationTests {

	@Test
	void contextLoads() {
	}

}
